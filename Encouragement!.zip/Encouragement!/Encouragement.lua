

--* Variables 
time = math.random(300,  900)
y = math.random(1, 4)
messagePlace = "nul"
local name = UnitName("player")


--*End Variables





    if y == 1 then 
    messagePlace = "Have a great day"

    elseif y == 2 then
       if name =="nonothing" then
        
            messagePlace = "Hello Reid's dad! (I have special messages for you :)"
    
        else  
           messagePlace = "Your doing great, " .. name .. "!"
       end

    elseif y == 3 then
        messagePlace = "I know this won't be easy, but I also know you've got what it takes to get through it."
    
    elseif y == 4 then
      messagePlace = "Pro WoW Tip: Struggling with a powerful foe? Make sure too keep your health above 0, while trying to get their health too 0. Works every time!"

    end 
message(messagePlace)


--*Slash Commands
SLASH_HELLO1 = "/em" 
SLASH_HELLO2 = "/encourageme"

function encourage()

    time = math.random(300,  900)
    y = math.random(1, 6)
    messagePlace = "nul"
    local name = UnitName("player") 


    if y == 1 then 
        messagePlace = "You got this!"
    
        elseif y == 2 then
           if name =="Mythalador" then
            
                messagePlace = "Hello Reid's dad!"
        
            else  
               messagePlace = "Your doing great, " .. name .. "!"
           end
    
        elseif y == 3 then
            messagePlace = "I know this won't be easy, but I also know you've got what it takes to get through it."
        
        elseif y == 4 then
          messagePlace = "Pro WoW Tip: Struggling with a powerful foe? Make sure too keep your health above 0, while trying to get their health too 0. Works every time!"
        
        elseif y == 5 then
            messagePlace = "You are amazing " .. name .. "!"
          
        elseif y == 6 then
            messagePlace = "Believe you can and you're halfway there"
        end
        message(messagePlace)

        sleep(time)
    end


    
SlashCmdList["HELLO"] = encourage

while true do
    encourage()

end